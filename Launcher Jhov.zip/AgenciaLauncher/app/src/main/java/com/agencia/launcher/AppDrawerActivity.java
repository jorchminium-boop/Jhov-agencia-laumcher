package com.agencia.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Collections;
import java.util.List;

public class AppDrawerActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 20, 24, 20);
        page.setBackgroundColor(Color.rgb(8,11,16));
        TextView title = new TextView(this);
        title.setText("APLICACIONES");
        title.setTextColor(Color.rgb(201,169,110));
        title.setTextSize(20);
        title.setPadding(0,0,0,18);
        page.addView(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, (a,c) -> a.loadLabel(pm).toString().compareToIgnoreCase(c.loadLabel(pm).toString()));
        for (ResolveInfo app : apps) {
            TextView item = new TextView(this);
            item.setText("  " + app.loadLabel(pm));
            item.setTextColor(Color.WHITE);
            item.setTextSize(16);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(12, 12, 12, 12);
            list.addView(item, new LinearLayout.LayoutParams(-1, 54));
            item.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName);
                if (launch != null) startActivity(launch);
            });
        }
        scroll.addView(list);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView back = new TextView(this);
        back.setText("←  VOLVER");
        back.setTextColor(Color.rgb(201,169,110));
        back.setTextSize(14);
        back.setPadding(4, 16, 4, 8);
        back.setOnClickListener(v -> finish());
        page.addView(back);
        setContentView(page);
    }
}
