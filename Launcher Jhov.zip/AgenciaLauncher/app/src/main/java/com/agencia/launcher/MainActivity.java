package com.agencia.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Launcher visual para estéreos Android 8, pantalla horizontal 16:9. */
public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView liveClock;
    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (liveClock != null) {
                liveClock.setText(new SimpleDateFormat("HH:mm", new Locale("es", "MX")).format(new Date()));
                handler.postDelayed(this, 1000);
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        Dashboard root = new Dashboard();
        ImageView art = new ImageView(this);
        art.setImageResource(R.drawable.dashboard);
        art.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(art, new Dashboard.Params(0f, 0f, 1f, 1f));

        // Hora dinámica sobre el reloj del diseño. La fecha del arte es decorativa.
        liveClock = new TextView(this);
        liveClock.setTextColor(Color.WHITE);
        liveClock.setTextSize(25);
        liveClock.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        liveClock.setGravity(Gravity.CENTER);
        liveClock.setShadowLayer(5, 0, 1, Color.BLACK);
        root.addView(liveClock, new Dashboard.Params(.44f, .105f, .13f, .10f));

        // Zonas táctiles transparentes sobre el diseño actualizado.
        addHotspot(root, .005f, .10f, .085f, .13f, "Inicio", () -> {});
        addHotspot(root, .005f, .24f, .085f, .13f, "Navegación", () -> openPackage("com.google.android.apps.maps", "com.waze"));
        addHotspot(root, .005f, .37f, .085f, .13f, "Música", () -> openFirst("com.spotify.music", "com.android.music"));
        addHotspot(root, .005f, .50f, .085f, .13f, "Brújula", () -> openPackage("com.google.android.apps.maps"));
        addHotspot(root, .005f, .63f, .085f, .13f, "Configuración", () -> openSettings("android.settings.SETTINGS"));
        addHotspot(root, .005f, .76f, .085f, .13f, "Aplicaciones", () -> startActivity(new Intent(this, AppDrawerActivity.class)));
        // CarPlay / Android Auto: abre ZLink5 si está instalado; los nombres de paquete varían por fabricante.
        addHotspot(root, .69f, .09f, .30f, .14f, "CarPlay / Android Auto", () -> openFirst("com.zjinnova.zlink", "com.zlink", "com.zjinnova.zlink5", "com.syu.carlink"));
        addHotspot(root, .69f, .24f, .30f, .09f, "Ubicación de estacionamiento", () -> openPackage("com.google.android.apps.maps"));
        addHotspot(root, .69f, .34f, .075f, .15f, "Diagnóstico", () -> openSettings("android.settings.SETTINGS"));
        addHotspot(root, .77f, .34f, .075f, .15f, "Spotify", () -> openFirst("com.spotify.music"));
        addHotspot(root, .85f, .34f, .075f, .15f, "Radio", () -> openFirst("com.android.fmradio", "com.microntek.radio", "com.tw.radio", "com.syu.radio"));
        addHotspot(root, .93f, .34f, .065f, .15f, "Ecualizador", () -> openFirst("com.android.equalizer", "com.android.musicfx", "com.microntek.eq"));
        addHotspot(root, .69f, .48f, .30f, .23f, "Navegación", () -> openPackage("com.google.android.apps.maps", "com.waze"));
        addHotspot(root, .09f, .77f, .60f, .20f, "Reproductor", () -> openFirst("com.spotify.music", "com.android.music"));
        addHotspot(root, .69f, .77f, .15f, .20f, "Cambio de aceite", () -> openSettings("android.settings.SETTINGS"));
        addHotspot(root, .85f, .77f, .14f, .20f, "Luces", () -> openSettings("android.settings.SETTINGS"));
        setContentView(root);
        handler.post(clockTick);
    }

    private void addHotspot(Dashboard root, float x, float y, float w, float h, String label, Runnable action) {
        View hit = new View(this);
        hit.setBackground(new ColorDrawable(Color.TRANSPARENT));
        hit.setContentDescription(label);
        hit.setOnClickListener(v -> { try { action.run(); } catch (Exception ignored) { } });
        root.addView(hit, new Dashboard.Params(x, y, w, h));
    }

    private void openPackage(String... packages) { openFirst(packages); }
    private void openFirst(String... packages) {
        PackageManager pm = getPackageManager();
        for (String pkg : packages) {
            Intent i = pm.getLaunchIntentForPackage(pkg);
            if (i != null) { startActivity(i); return; }
        }
        // Si no existe la aplicación, abre ajustes como alternativa segura.
        openSettings("android.settings.SETTINGS");
    }
    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }
    }
    @Override protected void onDestroy() { handler.removeCallbacks(clockTick); super.onDestroy(); }

    /** Layout relativo para mantener las zonas táctiles en cualquier 16:9. */
    private class Dashboard extends FrameLayout {
        Dashboard() { super(MainActivity.this); setBackgroundColor(Color.BLACK); }
        class Params extends FrameLayout.LayoutParams {
            final float x, y, w, h;
            Params(float x, float y, float w, float h) { super(1, 1); this.x=x; this.y=y; this.w=w; this.h=h; }
        }
        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int width = r-l, height = b-t;
            for (int i=0; i<getChildCount(); i++) {
                View child = getChildAt(i);
                if (child.getLayoutParams() instanceof Params) {
                    Params p = (Params) child.getLayoutParams();
                    int left = Math.round(width*p.x), top = Math.round(height*p.y);
                    child.layout(left, top, left+Math.round(width*p.w), top+Math.round(height*p.h));
                } else child.layout(0,0,width,height);
            }
        }
    }
}
