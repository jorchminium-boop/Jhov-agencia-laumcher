# Jhov Agencia Launcher

Proyecto Android nativo (Java) para estéreo horizontal 16:9 con Android 8.0+ (minSdk 26).

## Diseño actual
- Kia Rio blanco, panel azul oscuro y neón.
- Botón CarPlay / Android Auto que intenta abrir ZLink5.
- Spotify, radio, navegación, ajustes y cajón de aplicaciones.

## Importante sobre la funcionalidad
Los accesos abren aplicaciones si están instaladas y si el fabricante permite iniciarlas externamente. Los nombres de paquete de ZLink5, radio y ecualizador cambian según el estéreo; si el acceso no encuentra la app, habrá que identificar el paquete real en el equipo.

Los paneles OBD2, velocidad, clima, kilometraje, aceite y luces del arte son elementos visuales de referencia; todavía no están conectados a sensores ni servicios del vehículo. La hora sí se actualiza.

## Compilación
Requiere Android Gradle Plugin 8.2.2, Gradle compatible y Android SDK 34. Ejecutar `gradle assembleDebug` desde esta carpeta en un entorno con Android SDK. El APK resultante queda en `app/build/outputs/apk/debug/app-debug.apk`.
